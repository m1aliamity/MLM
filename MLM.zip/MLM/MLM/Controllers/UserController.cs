﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MLM.Repository.Interface;
using Models.WebModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MLM.Controllers
{
    public class UserController : Controller
    {
        private readonly IUserRepository _IUserRepository;
        public UserController(IUserRepository iUserRepository)
        {
            _IUserRepository = iUserRepository;
        }
        public IActionResult UserLogin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult UserLogin(UserModel model)
        {
            _IUserRepository.ValidateUser(model);
            if (model.MessageId == 0)
            {
                HttpContext.Session.SetInt32("UserId", model.UserId);
                HttpContext.Session.SetString("UserName", model.FirstName);
                HttpContext.Session.SetInt32("CID", model.ReferenceId);
                return RedirectToRoute(new { action = "UserDeshboard", controller = "UserDeshboard", area = "" });
            }
            return Json(model);
        }
        [HttpPost]
        public IActionResult UserRegistration(UserModel model)
        {
            
                _IUserRepository.UserRegistration(model);
                return Json(model);
        }
    }
}
