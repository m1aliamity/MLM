﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MLM.Controllers
{
    public class UserController : Controller
    {
        public IActionResult UserLogin()
        {
            return View();
        }
        public IActionResult UserRegistration()
        {
            return View();
        }
    }
}
