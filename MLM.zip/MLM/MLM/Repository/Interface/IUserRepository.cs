﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Models.WebModels;
namespace MLM.Repository.Interface
{
    public interface IUserRepository
    {
        Task ValidateUser(UserModel model);
        Task UserRegistration(UserModel model);
        Task UserOperations(UserModel model);
    }
}
