﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using MLM.Repository.Interface;
using Models.WebModels;
using DataAccess.Interface;

namespace MLM.Repository.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly IUserDAL _IUserDAL;
        public UserRepository(IUserDAL iUserDAL)
        {
            _IUserDAL = iUserDAL;
        }
        public async Task ValidateUser(UserModel model)
        {
            if (Isvalidate(model))
            {
                DataTable dt = await _IUserDAL.ValidateUser(model);
                if (dt.Rows.Count == 1)
                {
                    model.UserId = Convert.ToInt32(dt.Rows[0]["Id"]);
                    model.EmailId = Convert.ToString(dt.Rows[0]["UserName"]);
                }
                else
                {
                    model.MessageId = 1;
                    model.MessageText = Resources.ValidationMessage.InvalidUserPassword;
                }
            }
        }
        public bool Isvalidate(UserModel model)
        {
            bool status = true;
            if (string.IsNullOrEmpty(model.EmailId) || string.IsNullOrWhiteSpace(model.EmailId))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.UserName;
                status = false;
            }
            else if (string.IsNullOrEmpty(model.EmailId) || string.IsNullOrWhiteSpace(model.EmailId))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.UserName;
                status = false;
            }
            return status;
        }
        public async Task UserRegistration(UserModel model)
        {
            if (UserValidate(model))
            {
                DataTable dt = await _IUserDAL.UserRegistration(model);
                if (Convert.ToInt64(dt.Rows[0][0]) > 0)
                {
                    model.MessageId = 2;
                    model.MessageText = Resources.ValidationMessage.UserRegisterd;
                }
                else
                {
                    model.MessageId = 1;
                    model.MessageText = Resources.ValidationMessage.UserNotRegistered;
                }
            }
        }
        public bool UserValidate(UserModel model)
        {
            bool status = true;
            if (string.IsNullOrEmpty(model.FirstName) || string.IsNullOrWhiteSpace(model.FirstName))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.FName;
                status = false;
            }
            else if(string.IsNullOrEmpty(model.LastName) || string.IsNullOrWhiteSpace(model.LastName))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.LName;
                status = false;
            }
            else if (string.IsNullOrEmpty(model.EmailId) || string.IsNullOrWhiteSpace(model.EmailId))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.Emailid;
                status = false;
            }
            else if (string.IsNullOrEmpty(model.Password) || string.IsNullOrWhiteSpace(model.Password))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.Password;
                status = false;
            }
            else if (string.IsNullOrEmpty(model.ConfirmPassword) || string.IsNullOrWhiteSpace(model.ConfirmPassword))
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.ConfirmPassword;
                status = false;
            }
            else if (model.ConfirmPassword!=model.Password)
            {
                model.MessageId = 1;
                model.MessageText = Resources.ValidationMessage.PasswordNotMatch;
                status = false;
            }
            return status;
        }
        public async Task UserOperations(UserModel model)
        {
            DataSet ds = await _IUserDAL.UserOperations(model);
        }
    }
}
