﻿using DAL.Connection;
using DataAccess.Interface;
using Models.WebModels;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Implementation
{
    public class UserDAL : IUserDAL
    {
        private readonly MySqlHelperClass _objMySqlHelper;
        public UserDAL()
        {
            _objMySqlHelper = new MySqlHelperClass();
        }
        public async Task<DataTable> ValidateUser(UserModel model)
        {
                MySqlParameter[] cmdParams = {
                new MySqlParameter("@P_EmailId", model.EmailId),
                new MySqlParameter("@P_Password", model.Password), };
            return await _objMySqlHelper.SP_DataTable("USP_ValidateUser", cmdParams);
        }
        public async Task<DataTable> UserRegistration(UserModel model)
        {
            MySqlParameter[] cmdParams = {
                new MySqlParameter("@P_FirstName", model.FirstName),
                new MySqlParameter("@P_LastName", model.LastName),
                new MySqlParameter("@P_EmailId", model.EmailId),
                new MySqlParameter("@P_Password", model.Password),};
            return await _objMySqlHelper.SP_DataTable("USP_UserRegistration", cmdParams);
        }
        public async Task<DataSet> UserOperations(UserModel model)
        {
            MySqlParameter[] cmdParams = {
                new MySqlParameter("@P_Id", model.RowId),
                new MySqlParameter("@P_UserName", model.EmailId),
                new MySqlParameter("@P_Password", model.Password),
                new MySqlParameter("@P_StaffId", model.UserId),
                new MySqlParameter("@P_UserType", model.UserId),
                new MySqlParameter("@P_CID", model.UserId),
                new MySqlParameter("@P_ACTION", model.Action),};
            return await _objMySqlHelper.SP_DataSet("USP_UserOperations", cmdParams);
        }
    }
}
