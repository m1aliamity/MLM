﻿using Models.WebModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Interface
{
    public interface IUserDAL
    {
        Task<DataTable> ValidateUser(UserModel model);
        Task<DataTable> UserRegistration(UserModel model);
        Task<DataSet> UserOperations(UserModel model);
    }
}
