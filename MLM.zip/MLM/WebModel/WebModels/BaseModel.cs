﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models.WebModels
{
    public class BaseModel : DropDownModel
    {
        public int UserId { get; set; }
        public long RowId { get; set; }
        public int ReferenceId { get; set; }
        public long OrderId { get; set; }
        public int MessageId { get; set; }
        public long Status { get; set; }
        public string MessageText { get; set; }
        public string Action { get; set; }
        public string StatusName { get; set; }
        public List<DropDownModel> StatusList { get; set; }
    }
}
